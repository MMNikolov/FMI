#include "funcs.hpp"

template<typename T>
void init(array<T>& arr, const unsigned int size)
{
    int randomNum;
    for (unsigned int i = 0; i < size; i++)
    {
        randomNum = rand() % 100;
        arr.arr[i] = randomNum;   
    }
};

template<typename T>
void copy(array<T>& arr, const array<T>& other, const unsigned int size)
{
    for (unsigned int i = 0; i < size; i++)
    {
        arr.arr[i] = other.arr[i];
    }
};

template<typename T>
void add(array<T>& arr, const T& element)
{
    return;
}

template<typename T>
void remove(array<T>& arr, int index)
{
    return;
};

template<typename T>
void reverse(array<T>& arr)
{
    return;
};

template<typename T>
void print(const array<T>& arr, const unsigned int size)
{
    for (unsigned int i = 0; i < size; i++)
    {
        std::cout << "[" << arr.arr[i] << "]";
    }
    std::cout << "\n";
};