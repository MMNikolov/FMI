#pragma once

#include <iostream>
#include <cstdlib>
#include <ctime>
#define ARR_SIZE 128

template<typename T>
struct array
{
    T arr[ARR_SIZE];
};

template<typename T>
void init(array<T>& arr, const unsigned int size);
template<typename T>
void copy(array<T>& arr, const array<T>& other, const unsigned int size);
template<typename T>
void add(array<T>& arr, const T& elemt);
template<typename T>
void remove(array<T>& arr, int index);
template<typename T>
void reverse(array<T>& arr);
template<typename T>
void print(const array<T>& arr, const unsigned int size);