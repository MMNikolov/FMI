#include "funcs.hpp"

int main(){
    array<int> arr;
    int n;
    std::cout << "how many elements do you want the array to have: ";
    std::cin >> n;

    init(arr, n);
    print(arr, n);

    return 0;
}

