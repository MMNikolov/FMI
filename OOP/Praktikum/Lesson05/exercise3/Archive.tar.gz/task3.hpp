#pragma once

#include <iostream>
#include <ctime>
#include <cstdlib>
#define MAX_TUPLES 20

template<typename T1, typename T2>
struct Tuple
{
    T1 x;
    T2 y;
};

template<typename T1, typename T2>
struct Tuples
{
    Tuple<T1, T2> arrTuples[MAX_TUPLES];
};

template<typename T1, typename T2>
Tuple<T1, T2> init(Tuple<T1, T2>& tuple1);

//First task
//---------------------------------------

template<typename T1, typename T2, typename Res>
Tuple<T1, T2> add(Tuple<T1, T2>& tuple1, Tuple<T1, T2>& tuple2);

template<typename T1, typename T2, typename Res>
Tuple<T1, T2> mult(Tuple<T1, T2>& tuple1, Tuple<T1, T2>& tuple2);

template<typename T1, typename T2, typename Res>
Tuple<T1, T2> sub(Tuple<T1, T2>& tuple1, Tuple<T1, T2>& tuple2);

//Second task
//-------------------------------------------
//I dont know what they want from me here

//Third task
//------------------------------------------
template<typename T1, typename T2>
void display(Tuple<T1, T2>& tuple1);

//Fourth task
//----------------------------------------
//I dont know what they are asking of me

#include "task3.inl"
