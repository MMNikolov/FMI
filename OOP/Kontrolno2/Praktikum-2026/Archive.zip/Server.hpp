#pragma once

#include "MobileDevice.hpp"
#include "DesktopDevice.hpp"
#include "Connection.hpp"

//we would like to keep it to the power of 2 for optimization
#define STARTING_CONNECTIONS_SIZE 4

class Server
{
public:
    Server(unsigned capacity, unsigned timeout);

    //no need for copy ctors
    Server(const Server& other) = delete;
    Server& operator=(const Server& other) = delete;

    //we dont use dinamic memory
    ~Server();

    //methods
    bool connect(const Device& device);
    bool disconnect(int DeviceId);
    void tick(unsigned cnt = 1);
    void saveLog(const char* fileName);
    void loadLog(const char* fileName);

private:
    unsigned capacity;
    unsigned timeout;
    Connection connections[STARTING_CONNECTIONS_SIZE];

    void resize();
    void shrink();
};
