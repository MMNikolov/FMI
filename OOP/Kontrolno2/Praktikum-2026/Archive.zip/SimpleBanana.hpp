#pragma once

#include "Banana.hpp"

#define MAX_SORT_LENGTH 5

class SimpleBanana : public Banana
{
public:
    SimpleBanana(const char *name, unsigned weight, bool isHidden, bool isRotten, bool toEat, bool watchOnly, const char sort[MAX_SORT_LENGTH]);

    SimpleBanana(const SimpleBanana& other) = delete;
    SimpleBanana& operator=(const SimpleBanana& other) = delete;

    //methods
    friend std::ostream& operator<<(std::ostream& out, const SimpleBanana& simpleBanana);
    virtual void operator+(const char* info) override;

private:
    char sort[MAX_SORT_LENGTH];
};

std::ostream& operator<<(std::ostream& out, const SimpleBanana& simpleBanana);
