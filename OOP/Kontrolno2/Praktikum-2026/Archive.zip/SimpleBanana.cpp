#include "SimpleBanana.hpp"

SimpleBanana::SimpleBanana(const char *name, unsigned weight, bool isHidden, bool isRotten, bool toEat, bool watchOnly, const char sort[MAX_SORT_LENGTH])
    : Banana(name, weight, isHidden, isRotten, toEat, watchOnly)
{
    if (sort == '\0' || strlen(sort) > 5)
    {
        throw std::invalid_argument("Invalid inout");
    }
    
    strcpy(this->sort, sort);
}

void SimpleBanana::operator+(const char *info)
{
    //TO DO
}

std::ostream &operator<<(std::ostream &out, const SimpleBanana &simpleBanana)
{
    out << simpleBanana.Id << '-' << simpleBanana.sort << '-' << simpleBanana.name << '-' 
        << simpleBanana.weight << '-' << simpleBanana.isHidden << '-' << simpleBanana.isRotten << '-'
        << simpleBanana.toEat << '-' << simpleBanana.watchOnly << '\n';
}
