#pragma once

#include "Device.hpp"

class Connection
{
public:
    Connection(Device* device, unsigned tick);

    //copy ctor
    Connection(const Connection& other);
    Connection& operator=(const Connection& other);

    ~Connection();

private:
    Device* device;
    unsigned tick;

    void copyFrom(const Connection& other);
    void free();
};
