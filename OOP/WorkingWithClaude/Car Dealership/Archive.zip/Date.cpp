#include "Date.hpp"

Date::Date(short days, short months, short years, const char *date)
    : days(0), month(0), years(0), date(nullptr)
{
    if ((days < 0 || days > 31) || (months < 0 || months > 15) || (years < 0 || years > 63))
    {
        throw std::invalid_argument("Invalid parameters at the constructor for Date");
    }
    
    if (!validateDate(date))
    {
        throw std::invalid_argument("date is not correct");
    }
    
    this->date = new char[strlen(date) + 1];
    if (!this->date)
    {
        throw std::bad_alloc();
    }
    strcpy(this->date, date);

    this->days = days;
    this->month = months;
    this->years = years;
}

Date::Date(const Date &other)
{
    this->date = new char[strlen(other.date) + 1];
    if (!this->date)
    {
        throw std::bad_alloc();
    }
    strcpy(this->date, other.date);

    this->days = other.days;
    this->month = other.month;
    this->years = other.years;
}

Date &Date::operator=(const Date &other)
{
    if (this != &other)
    {
        char* tempDate = new char[strlen(other.date) + 1];
        if (!tempDate)
        {
            throw std::bad_alloc();
        }
        strcpy(this->date, other.date);

        free();

        this->date = tempDate;
        this->days = other.days;
        this->month = other.month;
        this->years = other.years;
    }
    
    return *this;
}

Date::~Date()
{
    free();
}

void Date::print(std::ofstream& out) const
{
    out << this->date[0] << this->date[1] << '/'
        << this->date[3] << this->date[4] << '/'
        << this->date[6] << this->date[7] << this->date[8] << this->date[9];
};

void Date::free()
{
    delete[] this->date;
}

bool Date::validateDate(const char *date)
{
    if (!date)
    {
        return false;
    }
    
    if (!IsNumber(date[0])) { return false; }
    if (!IsNumber(date[1])) { return false; }
    if (date[2] != '/') { return false; }
    if (!IsNumber(date[3])) { return false; }
    if (!IsNumber(date[4])) { return false; }
    if (date[5] != '/') { return false; }
    if (!IsNumber(date[6])) { return false; }
    if (!IsNumber(date[7])) { return false; }
    if (!IsNumber(date[8])) { return false; }
    if (!IsNumber(date[9])) { return false; }
    
    return true;
}

bool IsNumber(const char c)
{
    return (c >= '0' && c <= '9');
}
