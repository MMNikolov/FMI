#ifndef DATE_HPP
#define DATE_HPP

#include <iostream>
#include <stdexcept>
#include <fstream>
#include <cstring>

class Date
{
public:
    //ordinary ctor
    Date(short days, short months, short years, const char* date);

    //copy constructor
    Date(const Date& other);
    Date& operator=(const Date& other);

    //destructor
    ~Date();

    //methods
    void print(std::ofstream& out) const;

    //getters
    short getDays() const { return this->days; };
    short getMonths() const { return this->month; };
    short getYears() const { return this->years; };
    const char* getDate() const { return this->date; };

private:
    short days : 5;
    short month : 4;
    short years : 6;
    char* date;

private:
    void free();
    bool validateDate(const char* date);
};

bool IsNumber(const char c);

#endif // DATE_HPP