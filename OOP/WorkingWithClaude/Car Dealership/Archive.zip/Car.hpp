#ifndef CAR_HPP
#define CAR_HPP

#include "Date.hpp"

class Car
{
public:
    Car(const char* model, const Date& date, const char* trunk, unsigned horsePower, unsigned seats, bool IsDrivable);
    Car(std::ifstream& in);

    //copy ctor
    Car(const Car& other);
    Car& operator=(const Car& other);

    //destructor
    ~Car();

    //methods
    void print(const std::ofstream& out) const;

    //getters
    const char* getModel() const { return this->model; };
    Date getDate() const { return this->dateOfManufacure; };
    const char* getTrunk() const { return this->trunk; };
    unsigned getHorsePower() const { return this->horsePower; };
    unsigned getSeats() const { return this->seats; };
    bool getIsDrivable() const { return this->isDrivable; };

private:
    char* model;
    const Date dateOfManufacure;
    const char* trunk;
    unsigned horsePower;
    unsigned seats;
    bool isDrivable;

private:    
    void free();
};

const char* isTrunkValid(const char* trunk);
bool isSedan(const char* trunk);
bool isHatchBack(const char* trunk);
bool isKombi(const char* trunk);

#endif // CAR_HPP