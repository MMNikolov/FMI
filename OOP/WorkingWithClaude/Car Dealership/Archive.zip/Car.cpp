#include "Car.hpp"

Car::Car(const char *model, const Date &date, const char *trunk, unsigned horsePower, unsigned seats, bool IsDrivable)
    : model(nullptr), date(date), trunk(isTrunkValid(trunk)), horsePower(0), seats(0), isDrivable(false)
{
    if (!this->model)
    {
        throw std::invalid_argument("Model isnt written down");
    }
    
    this->model = new char[strlen(model) + 1];
    if (!this->model)
    {
        throw std::bad_alloc();
    }
    strcpy(this->model, model);
}

const char *isTrunkValid(const char *trunk)
{
    if (!trunk)
    {
        throw std::invalid_argument("The trunk isnt described");
    }
    
    if (isSedan(trunk) || isHatchBack(trunk) || isKombi(trunk))
    {
        return trunk;
    }
    
    return nullptr;
}

bool isSedan(const char *trunk)
{
    if (trunk[0] != 'S') {  return false; };
    if (trunk[1] != 'e') {  return false; };
    if (trunk[2] != 'd') {  return false; };
    if (trunk[3] != 'a') {  return false; };
    if (trunk[4] != 'n') {  return false; };
       
    return true;
}

bool isHatchBack(const char *trunk)
{
    if (trunk[0] != 'H') {  return false; };
    if (trunk[1] != 'a') {  return false; };
    if (trunk[2] != 't') {  return false; };
    if (trunk[3] != 'c') {  return false; };
    if (trunk[4] != 'h') {  return false; };
    if (trunk[5] != 'b') {  return false; };
    if (trunk[6] != 'a') {  return false; };
    if (trunk[7] != 'c') {  return false; };
    if (trunk[8] != 'k') {  return false; };

    return true;
}

bool isKombi(const char *trunk)
{
    if (trunk[0] != 'K') {  return false; };
    if (trunk[1] != 'o') {  return false; };
    if (trunk[2] != 'm') {  return false; };
    if (trunk[3] != 'b') {  return false; };
    if (trunk[4] != 'i') {  return false; };

    return true;
}
