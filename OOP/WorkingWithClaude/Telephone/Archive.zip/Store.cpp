#include "Store.hpp"

Store::Store(const double budget)
    : budget(validateBudget(budget)), count(0), capacity(STARTING_CAPACITY), currentBudget(0)
{
    this->phones = new Telephone*[capacity];
    for (unsigned i = 0; i < capacity; i++)
    {
        this->phones[i] = nullptr;
    }
}

Store::Store(const Store &other)
    : budget(other.budget), count(other.count), capacity(other.capacity), currentBudget(other.currentBudget)
{
    this->phones = new Telephone*[capacity];
    for (unsigned i = 0; i < count; i++)
    {
        this->phones[i] = other.phones[i]->clone();
    }
}

Store &Store::operator=(const Store &other)
{
    if (this != &other)
    {
        // claude can u help me with this. I know what I should be doing I should be calling
        //the copy constructor, because I have a const in the store variables, but I dont know how to execute it
    }
    
    return *this;
}

Store::~Store()
{
    free();
}

void Store::addTelephone(const Telephone &phone)
{
    if (this->count >= this->capacity)
    {
        resize();
    }

    if (this->currentBudget + phone.getPrice() >= this->budget)
    {
        throw std::invalid_argument("There isnt enough money :(");
    }
    
    this->phones[count++] = phone.clone();
    this->currentBudget += phone.getPrice();
}

bool Store::removeTelephone(const char *model, const char *brand)
{
    if (!model || !brand)
    {
        throw std::invalid_argument("There mus be a brand or a model that we can search for");
    }
    
    for (unsigned i = 0; i < this->count; i++)
    {
        if ((strcmp(this->phones[i]->getBrand(), brand) == 0) &&
            (strcmp(this->phones[i]->getModel(), model) == 0))
        {
            this->currentBudget += this->phones[i]->getPrice();
            delete this->phones[i];
            this->phones[i] = this->phones[count];
            this->phones[count--] = nullptr;
            return true;
        }
    }
    
    return false;
}

void Store::free()
{
    if (this->count <= 0)
    {
        throw std::invalid_argument("Cant delete something that isnt there");
    }
    
    for (unsigned i = 0; i < count; i++)
    {
        delete this->phones[i];
    }

    delete[] this->phones;
}

void Store::resize()
{
    Telephone** tempPhones = new Telephone*[capacity * 2];
    for (unsigned i = 0; i < count; i++)
    {
        tempPhones[i] = this->phones[i]->clone();
    }
    
    free();

    this->phones = tempPhones;
    for (unsigned i = 0; i < count; i++)
    {
        this->phones[i] = tempPhones[i]->clone();
    }
    
    this->count *= 2;
    //I am not sure if we are leaving them in a valid state after the count, because we dont know if we are assigning them nullptrs
}

double validateBudget(const double budget)
{
    if (budget <= 0)
    {
        throw std::invalid_argument("Budget is too low to start a phone bussiness");
    }
    
    return budget;
}
