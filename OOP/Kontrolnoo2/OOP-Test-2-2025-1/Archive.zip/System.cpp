#include "System.hpp"

System::System(const char *name)
{
    if (!name)
    {
        throw std::invalid_argument("Invlaid inout in the system");
    }
    
    this->name = new char[strlen(name) + 1];
    strcpy(this->name, name);
}

System::System(const System &other)
{
    copyFrom(other);
}

System &System::operator=(const System &other)
{
    if (this != &other)
    {
        free();
        copyFrom(other);
    }
    
    return *this;
}

System::~System()
{
    free();
}

void System::operator+(const User &user)
{
    //if we want to optimize this system we would have ordered them lexicographique
    //and then search for the person letter by letter. This helps with time complexity if the system becomes to big
    for (unsigned i = 0; i < this->count; i++)
    {
        if (strcmp(this->users[i]->GetEmail(), user.GetEmail()) == 0)
        {
            std::cout << "There is already a user with this email\n";
            return;
        }
    }
    
    //Ask gemini why doesnt this work when the data we provide is "const" User& user
    //this->users[this->count++] = user.clone();
}

void System::copyFrom(const System &other)
{
    this->name = new char[strlen(other.name) + 1];
    strcpy(this->name, other.name);

    for (unsigned i = 0; i < this->capacity; i++)
    {
        delete[] this->users[i];
        this->users[i] = nullptr;
    }
    
    this->count = 0;
    this->capacity = capacity;
    this->hasSuperUser = false;
}

void System::free()
{
    delete[] this->name;
    this->name = nullptr;

    for (unsigned i = 0; i < count; i++)
    {
        delete[] this->users[i];
    }
    
    delete this->users;
}
