#pragma once

#include "Player.hpp"

class PlayerCollection
{
public:
    PlayerCollection();
    ~PlayerCollection();
    
    //methods
    bool addPlayer(const Player& player);
    Player& operator[](unsigned index);
    bool removePlayer(const char* name);

private:
    Player** players;
    unsigned count;

private:
    void free();
};
